package com.legacyofthesaiyans.network;

import com.legacyofthesaiyans.form.TransformationManager;
import com.legacyofthesaiyans.ki.KiManager;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/**
 * Client -> server. action: 0 = stop charging, 1 = start charging, 2 = fire Ki blast,
 * 3 = transform to the next form, 4 = return to base form.
 */
public class KiActionPacket {
    private final int action;

    public KiActionPacket(int action) {
        this.action = action;
    }

    public static void encode(KiActionPacket packet, FriendlyByteBuf buf) {
        buf.writeVarInt(packet.action);
    }

    public static KiActionPacket decode(FriendlyByteBuf buf) {
        return new KiActionPacket(buf.readVarInt());
    }

    public static void handle(KiActionPacket packet, Supplier<NetworkEvent.Context> ctxSupplier) {
        NetworkEvent.Context ctx = ctxSupplier.get();
        ctx.enqueueWork(() -> {
            ServerPlayer player = ctx.getSender();
            if (player == null) {
                return;
            }
            switch (packet.action) {
                case 0 -> KiManager.setCharging(player, false);
                case 1 -> KiManager.setCharging(player, true);
                case 2 -> KiManager.tryFire(player);
                case 3 -> TransformationManager.transformUp(player);
                case 4 -> TransformationManager.revert(player, "Vuelves a tu forma base");
                default -> { }
            }
        });
        ctx.setPacketHandled(true);
    }
}
