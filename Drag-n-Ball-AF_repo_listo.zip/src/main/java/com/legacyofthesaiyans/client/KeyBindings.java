package com.legacyofthesaiyans.client;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;
import org.lwjgl.glfw.GLFW;

public final class KeyBindings {
    public static final String CATEGORY = "key.categories.legacyofthesaiyans";

    public static final KeyMapping CHARGE_KI = new KeyMapping(
            "key.legacyofthesaiyans.charge_ki", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_C, CATEGORY);
    public static final KeyMapping FIRE_KI = new KeyMapping(
            "key.legacyofthesaiyans.fire_ki", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_V, CATEGORY);
    public static final KeyMapping TRANSFORM = new KeyMapping(
            "key.legacyofthesaiyans.transform", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_G, CATEGORY);
    public static final KeyMapping REVERT = new KeyMapping(
            "key.legacyofthesaiyans.revert", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_H, CATEGORY);

    private KeyBindings() {}
}
