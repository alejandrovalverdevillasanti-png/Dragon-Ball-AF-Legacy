package com.legacyofthesaiyans.progression;
import net.minecraft.server.level.ServerPlayer;

/** Server-side progress helpers; client key input/network packets remain to be implemented. */
public final class BreakLimitProgression {
    private static final double MAX_CHARGE = 100.0D;
    private BreakLimitProgression() {}
    public static double getCharge(ServerPlayer player) {
        return Math.max(0.0D, Math.min(MAX_CHARGE,
                player.getPersistentData().getDouble(ProgressionKeys.BREAK_CHARGE)));
    }
    public static int getLevel(ServerPlayer player) {
        return Math.max(0, Math.min(4,
                player.getPersistentData().getInt(ProgressionKeys.BREAK_LEVEL)));
    }
    /** Adds server-validated charge. Returns true when a new tier is reached. */
    public static boolean addCharge(ServerPlayer player, double amount) {
        if (!Double.isFinite(amount) || amount <= 0.0D) return false;
        double next = Math.min(MAX_CHARGE, getCharge(player) + amount);
        if (next >= MAX_CHARGE) {
            player.getPersistentData().putDouble(ProgressionKeys.BREAK_CHARGE, 0.0D);
            player.getPersistentData().putInt(ProgressionKeys.BREAK_LEVEL,
                    Math.min(4, getLevel(player) + 1));
            return true;
        }
        player.getPersistentData().putDouble(ProgressionKeys.BREAK_CHARGE, next);
        return false;
    }
}
