# Estado real del proyecto – Dragon Ball AF: Legacy of the Saiyans

## Base existente
- Proyecto orientado a Minecraft 1.20.1 / Forge 47.2.0 / Java 17.
- Código inicial para razas, progresión, Zenkai, transformaciones y Ki.
- Configuración, recursos iniciales y workflow de GitHub Actions.

## Estado de verificación
- La compilación local no se ha verificado en este entorno porque no está disponible el comando Gradle.
- El JAR 0.5.0 que apareció en los archivos anteriores no se considera probado en Minecraft ni en Zalith.
- La compatibilidad con Zalith sigue siendo un objetivo pendiente de prueba real.

## Pendiente
- Revisar y compilar toda la base.
- Conectar completamente Break Limit a entrada, red, servidor y HUD.
- Completar razas, transformaciones, modelos, animaciones y técnicas.
- Añadir entidades, villanos, dinosaurios, monstruos y jefes.
- Generar Monte Paoz, ciudades, estructuras y NPC.
- Implementar minimapa, marcadores y mapas por universo.
- Implementar Pistola Multiversal, Britannia y Laboratorio de Combates.
- Completar historia, planetas, dimensiones, misiones y pruebas en cliente.

## Especificación ampliada
Consultar `FEATURES_INTEGRADAS_ES.md` para el alcance detallado de todas las nuevas características solicitadas.

## Primera integración de código (pendiente de compilación)
- Tecla B conectada al servidor para cargar Break Limit.
- La carga aumenta 2 puntos por tick mientras se mantiene pulsada; al llegar al 100% sube un nivel (máximo 4) y activa durante 10 segundos efectos temporales de fuerza y velocidad.
- Aún faltan minijuego de ritmo, HUD de carga, auras personalizadas y balance por raza.
