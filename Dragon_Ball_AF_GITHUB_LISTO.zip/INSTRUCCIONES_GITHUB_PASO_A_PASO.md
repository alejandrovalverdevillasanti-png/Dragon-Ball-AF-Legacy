# Preparar el proyecto en GitHub (desde Android)

## Qué contiene este paquete
Este ZIP ya tiene el proyecto extraído en la raíz: `build.gradle`, `settings.gradle`, `src/` y `.github/workflows/build.yml`. **No subas este ZIP dentro de otro repositorio esperando que Actions lo descomprima**; primero extrae su contenido.

## Opción sencilla desde el navegador del móvil
1. Descarga y extrae `Dragon_Ball_AF_GITHUB_LISTO.zip` en tu móvil.
2. Abre tu repositorio de GitHub.
3. Si el repositorio solo contiene el ZIP anterior, puedes crear un repositorio nuevo o limpiar los archivos antiguos.
4. Sube el contenido extraído, no la carpeta contenedora: en la raíz del repositorio deben verse `build.gradle`, `settings.gradle`, `gradle.properties`, `src` y `.github`.
5. Comprueba que el archivo de workflow está exactamente en `.github/workflows/build.yml`.
6. Abre la pestaña **Actions**.
7. Selecciona **Dragon Ball AF - Forge 1.20.1** y pulsa **Run workflow**. También se ejecuta al hacer push a `main` o `master`.
8. Espera a que termine. Si sale verde, abre la ejecución y baja hasta **Artifacts**.
9. Descarga `Dragon-Ball-AF-Forge-1.20.1`; dentro estará el JAR generado en `build/libs`.

## Si falla
- Abre la ejecución roja en Actions.
- Entra en el paso que tenga la X roja.
- Copia el primer mensaje `FAILURE` o `error` y compártelo; no basta con una captura del resumen.
- No cambies versiones al azar. Este proyecto apunta a Minecraft 1.20.1, Forge 47.2.0 y Java 17.

## Instalar y probar
Copia el JAR descargado a `mods` de una instancia Minecraft Java 1.20.1 con Forge 47.2.0. Haz una copia de seguridad del mundo antes de probarlo. Zalith debe verificarse en el dispositivo real; que compile en GitHub no garantiza por sí solo que funcione allí.

## Estado honesto
El proyecto base contiene código inicial de Ki, transformaciones, progresión y Zenkai, además de una primera integración de Break Limit. Los sistemas grandes del plan (criaturas/villanos, Monte Paoz/ciudades, minimapa, pistola multiversal/Britannia y laboratorio Goku–Meliodas) siguen siendo trabajo de desarrollo; el documento `FEATURES_INTEGRADAS_ES.md` describe el alcance. No están implementados solo por aparecer en la planificación.
