# DRAGON BALL AF – LEGACY OF THE SAIYANS
## Integración de nuevas características solicitadas

Este documento incorpora al alcance del proyecto las nuevas ideas solicitadas. **No significa que todas estén ya programadas**: describe qué debe implementarse y cómo se conectará con la base Forge 1.20.1.

## 1. Mundo, regiones y ciudades

### Monte Paoz
- Región montañosa inspirada en el lugar donde Goku creció.
- Casa de Son Gohan, bosques, ríos, cascadas, cuevas, zonas de pesca y entrenamiento.
- Fósiles, recursos, secretos, misiones de exploración y puntos de interés.
- Dinosaurios y fauna salvaje con ciclos de actividad, alimentación y territorios.
- La región debe ser explorable, con interiores y lugares interactivos, no solo decoración.

### Ciudades
- West City, Satan City, Orange City, Capital del Este, Ciudad del Norte y Villa Pingüino, además de ciudades originales.
- Barrios residenciales, comercios, hospitales, escuelas, restaurantes, estadios, laboratorios, estaciones y edificios gubernamentales.
- NPC con rutinas, diálogos, trabajos, comercio y misiones.
- Vehículos terrestres y voladores.
- Invasiones, evacuaciones, daños configurables y reconstrucción.
- Ciudades y asentamientos en otros planetas y universos.

## 2. Criaturas, dinosaurios, monstruos y villanos

- Dinosaurios: T-Rex, Triceratops, Stegosaurus, Brontosaurus, pterosaurios, pequeños carnívoros, herbívoros gigantes y especies acuáticas.
- Fauna de bosques, montañas, cuevas, pantanos, volcanes, océanos y planetas alienígenas.
- Monstruos mutantes, demonios, guardianes de ruinas y criaturas experimentales.
- Jefes originales: Rex Alpha, Triceratops Colosal, Rex Mutante y otros.
- IA con alimentación, caza, huida, defensa territorial, manadas, protección de crías y ciclos de actividad.
- Huevos, crianza, domesticación selectiva y monturas donde corresponda.

### Villanos y jefes de Dragon Ball
- Cell: formas imperfecta, semiperfecta, perfecta y Super Perfect Cell; absorción y evolución.
- Majin Buu: Buu gordo, malvado, Super Buu, absorciones y Kid Buu; regeneración y cambio de forma.
- Freezer y sus transformaciones.
- Zamasu y Zamasu fusionado.
- Broly y sus estados de poder.
- Dabura y enemigos del reino demoníaco.
- Villanos y personajes AF: Xicor/Zaiko, Gohan Devil, Saiyans oscuros y guerreros de dimensiones alternativas.
- Cada jefe debe tener técnicas, patrones de IA, fases, resistencias y recompensas propias.

## 3. Sistema BREAK LIMIT – Romper tus límites

- Activación mediante tecla configurable.
- Fase de acumulación de energía y desafío de ritmo/tiempo.
- Niveles de sobrecarga con mejoras temporales de fuerza, velocidad, Ki y técnicas.
- Efectos visuales: aura, partículas, ondas de choque y animaciones.
- Coste elevado de Ki y agotamiento al finalizar.
- Variantes raciales: Saiyan, Namekiano, Majin, Clan de Freezer, Humano, Demonio, Androide, Kaioshin y otras razas.
- Entrenamiento y dominio necesarios para soportar niveles superiores.
- La sobrecarga no debe otorgar poder infinito ni activarse sin coste.

## 4. Pistola Multiversal y universo de Los Siete Pecados Capitales

- Objeto tecnológico que abre portales entre universos.
- Primer destino especial: Britannia, universo de *The Seven Deadly Sins*.
- Viaje de ida y regreso, coordenadas guardadas y transporte de compañeros.
- Regiones: Liones, bosque del Rey Hada, Camelot, reino demoníaco y otros lugares.
- Personajes y facciones: Meliodas, Ban, King, Diane, Merlin, Escanor, Elizabeth, Zeldris y los Diez Mandamientos.
- Magia y Ki son sistemas separados, con interacciones y resistencias configurables.
- Los portales y viajes deben tener límites/costes para evitar viajes accidentales o exploits.

## 5. Laboratorio de Combates Multiversales

- Instalación para seleccionar dos o más combatientes de universos distintos.
- Combate amistoso, automático, por rondas, máximo poder y personalizado.
- Primer combate de prueba destacado: Goku contra Meliodas.
- También permitir Goku contra Ban, King, Diane, Escanor y equipos completos.
- Selección de formas, técnicas, reglas, arena y condiciones.
- IA que esquiva, bloquea, contraataca, vuela, usa Ki o magia y cambia de estrategia.
- Estadísticas en tiempo real, historial, clasificación y repetición de combates.
- El resultado debe depender de atributos, configuración y comportamiento, no imponer que un universo siempre gane.

## 6. Minimapa y navegación

- Minimapa pequeño visible en una esquina de la pantalla.
- Posición, orientación, coordenadas y waypoints.
- Marcadores configurables para aliados, NPC, enemigos, jefes, Dragon Balls, ciudades, cuevas, estructuras y portales.
- Tamaño, transparencia, esquina y visibilidad configurables.
- Vista ampliada bajo demanda.
- Mapas independientes por planeta, dimensión y universo.
- Al viajar a Britannia, cargar el mapa de ese universo y conservar los waypoints descubiertos.

## 7. Integración con sistemas ya solicitados

Estas características deben conectarse con la progresión, razas, transformaciones, Ki, Zenkai, entrenamiento, historia, torneos, maestros, planetas y dimensiones ya definidos para el proyecto. Las nuevas funciones no deben reemplazar los sistemas existentes.

## 8. Orden de implementación recomendado

1. **Base jugable y estabilidad:** compilar, iniciar Forge 1.20.1, registro de entidades/ítems, guardado y red.
2. **BREAK LIMIT:** conectar tecla, paquete de red, servidor, costes, estados y efectos.
3. **Criaturas y villanos:** entidades, atributos, IA, ataques, transformaciones y jefes.
4. **Monte Paoz y ciudades:** biomas/regiones, estructuras, interiores, NPC y generación.
5. **Minimapa:** datos de posición, marcadores, waypoints, interfaz y mapas por dimensión.
6. **Pistola Multiversal:** portal, destino Britannia, retorno y persistencia de coordenadas.
7. **Laboratorio de combates:** interfaz de selección, arenas, IA de combate, rondas y resultados.
8. **Pruebas:** cliente Forge, mundo nuevo, multijugador y Zalith en el dispositivo objetivo.

## 9. Estado honesto

La base de código existente contiene sistemas iniciales de progresión, Ki, transformaciones y Zenkai, pero la integración completa de las características de este documento **todavía requiere programación**. No se debe marcar una función como terminada hasta que esté implementada, compilada y probada. La compatibilidad con Zalith también debe verificarse en el dispositivo; no se da por garantizada solo por compilar para Forge.
