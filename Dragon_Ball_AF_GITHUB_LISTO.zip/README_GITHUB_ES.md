# DRAGON BALL AF – LEGACY OF THE SAIYANS

Proyecto Minecraft Java 1.20.1 / Forge 47.2.0 / Java 17.

## Compilar con GitHub Actions
Consulta `INSTRUCCIONES_GITHUB_PASO_A_PASO.md`. El workflow está preparado para un repositorio que tenga el código fuente directamente en su raíz.

## Documentación
- `FEATURES_INTEGRADAS_ES.md`: especificación de las características.
- `PLAN_DE_DESARROLLO_GITHUB.md`: orden de implementación.
- `ROADMAP_REAL_ES.md`: estado y limitaciones conocidas.

**Aviso:** el workflow compila el código que está en el repositorio. No implementa automáticamente las características pendientes ni garantiza compatibilidad con Zalith. El JAR solo debe considerarse válido después de que Actions termine correctamente y se pruebe en Minecraft.
