# Plan de trabajo para GitHub

Crear Issues separadas y cerrar cada una solo tras compilar y probar:

1. **BREAK LIMIT**: revisar la primera integración, añadir HUD de carga, minijuego de control, coste de Ki, efectos y balance racial.
2. **Entidades**: crear base de entidades y registros; después dinosaurios/fauna, monstruos, Cell y Majin Buu con IA y habilidades.
3. **Mundo**: generar Monte Paoz, casa de Son Gohan, biomas, ciudades, estructuras e interiores; luego NPC y misiones.
4. **Minimapa**: HUD configurable, orientación, waypoints y marcadores; persistencia por dimensión/universo.
5. **Pistola multiversal**: portal seguro, destino Britannia, retorno, persistencia y reglas de viaje.
6. **Laboratorio de combate**: selector de luchadores/formas, arenas, IA, rondas, resultados y Goku contra Meliodas.
7. **QA**: compilar en Actions, iniciar cliente Forge 1.20.1, revisar logs, probar mundo nuevo y probar Zalith en el móvil.

Dependencias recomendadas: no construir el laboratorio antes de disponer de entidades/IA; no integrar el minimapa antes de definir dimensiones y puntos de interés; primero debe quedar estable la base de Forge.
