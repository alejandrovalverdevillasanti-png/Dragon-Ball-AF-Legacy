package com.legacyofthesaiyans.progression;

import com.legacyofthesaiyans.LegacyOfTheSaiyans;
import com.legacyofthesaiyans.config.LegacyConfig;
import com.legacyofthesaiyans.race.Race;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.entity.player.PlayerEvent.PlayerRespawnEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.Locale;

/**
 * Progression: tracks damage received, awards a permanent Zenkai on death, copies it
 * across the death/respawn player clone, reapplies stats and tells the player.
 */
@Mod.EventBusSubscriber(modid = LegacyOfTheSaiyans.MOD_ID, bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class ZenkaiEvents {
    private static final String ROOT = LegacyOfTheSaiyans.MOD_ID + ".";
    private static final String DAMAGE_SINCE_LAST_ZENKAI = ROOT + "damage_since_zenkai";
    private static final String PERMANENT_ZENKAI = ROOT + "permanent_zenkai";
    private static final String ZENKAI_COUNT = ROOT + "zenkai_count";
    private static final String PENDING_REWARD = ROOT + "pending_zenkai_reward";

    private ZenkaiEvents() {}

    public static double getZenkaiTotal(Player player) {
        return player.getPersistentData().getDouble(PERMANENT_ZENKAI);
    }

    public static int getZenkaiCount(Player player) {
        return player.getPersistentData().getInt(ZENKAI_COUNT);
    }

    public static double getAttackBonus(Player player) {
        double total = getZenkaiTotal(player);
        return total > 0.0D ? Math.log1p(total) * 0.25D : 0.0D;
    }

    public static void addZenkai(ServerPlayer player, double amount) {
        CompoundTag data = player.getPersistentData();
        data.putDouble(PERMANENT_ZENKAI, data.getDouble(PERMANENT_ZENKAI) + amount);
        StatsManager.recalc(player);
    }

    @SubscribeEvent
    public static void onPlayerHurt(LivingHurtEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer player) || event.getAmount() <= 0.0F) {
            return;
        }
        CompoundTag data = player.getPersistentData();
        data.putDouble(DAMAGE_SINCE_LAST_ZENKAI, data.getDouble(DAMAGE_SINCE_LAST_ZENKAI) + event.getAmount());
    }

    @SubscribeEvent
    public static void onPlayerDeath(LivingDeathEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer player)
                || !LegacyConfig.ENABLE_PERMANENT_ZENKAI.get()) {
            return;
        }

        CompoundTag data = player.getPersistentData();
        double damage = data.getDouble(DAMAGE_SINCE_LAST_ZENKAI);
        Race race = StatsManager.getRace(player);
        double raceMultiplier = race != null ? race.getZenkaiMultiplier() : 1.0D;

        double reward = Math.max(1.0D, Math.sqrt(Math.max(1.0D, damage)) * 0.10D)
                * LegacyConfig.ZENKAI_BASE_MULTIPLIER.get() * raceMultiplier;
        data.putDouble(PERMANENT_ZENKAI, data.getDouble(PERMANENT_ZENKAI) + reward);
        data.putInt(ZENKAI_COUNT, data.getInt(ZENKAI_COUNT) + 1);
        data.putDouble(DAMAGE_SINCE_LAST_ZENKAI, 0.0D);
        data.putDouble(PENDING_REWARD, reward);
    }

    @SubscribeEvent
    public static void onPlayerClone(PlayerEvent.Clone event) {
        CompoundTag oldData = event.getOriginal().getPersistentData();
        CompoundTag newData = event.getEntity().getPersistentData();
        copyIfPresent(oldData, newData, PERMANENT_ZENKAI);
        copyIfPresent(oldData, newData, ZENKAI_COUNT);
        copyIfPresent(oldData, newData, DAMAGE_SINCE_LAST_ZENKAI);
        copyIfPresent(oldData, newData, PENDING_REWARD);
    }

    @SubscribeEvent
    public static void onRespawn(PlayerRespawnEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer player)) {
            return;
        }
        StatsManager.recalc(player);

        CompoundTag data = player.getPersistentData();
        double reward = data.getDouble(PENDING_REWARD);
        if (reward > 0.0D) {
            data.putDouble(PENDING_REWARD, 0.0D);
            String text = String.format(Locale.ROOT,
                    "\u00A76\u00A1ZENKAI! \u00A7eHas ganado +%.2f de Zenkai permanente. \u00A7aBonus de ataque por Zenkai: +%.2f",
                    reward, getAttackBonus(player));
            player.sendSystemMessage(Component.literal(text));
        }
    }

    @SubscribeEvent
    public static void onLogin(PlayerEvent.PlayerLoggedInEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer player)) {
            return;
        }
        StatsManager.recalc(player);
        if (StatsManager.getRace(player) == null) {
            player.sendSystemMessage(Component.literal("\u00A76[Legacy of the Saiyans] \u00A7eAun no tienes raza. Escribe \u00A7b/raza\u00A7e para elegir una."));
        }
    }

    private static void copyIfPresent(CompoundTag from, CompoundTag to, String key) {
        if (from.contains(key)) {
            to.put(key, from.get(key).copy());
        }
    }
}
