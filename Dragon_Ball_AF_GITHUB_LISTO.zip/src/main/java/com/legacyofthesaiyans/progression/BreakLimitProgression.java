package com.legacyofthesaiyans.progression;

import com.legacyofthesaiyans.LegacyOfTheSaiyans;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** First playable server-side Break Limit implementation. */
@Mod.EventBusSubscriber(modid = LegacyOfTheSaiyans.MOD_ID, bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class BreakLimitProgression {
    private static final double MAX_CHARGE = 100.0D;
    private static final String ACTIVE = "legacyofthesaiyans.break_active";
    private static final String BURST_TICKS = "legacyofthesaiyans.break_burst_ticks";
    private BreakLimitProgression() {}
    public static double getCharge(ServerPlayer player) {
        return Math.max(0.0D, Math.min(MAX_CHARGE, player.getPersistentData().getDouble(ProgressionKeys.BREAK_CHARGE)));
    }
    public static int getLevel(ServerPlayer player) {
        return Math.max(0, Math.min(4, player.getPersistentData().getInt(ProgressionKeys.BREAK_LEVEL)));
    }
    public static void setActive(ServerPlayer player, boolean active) {
        if (active && getLevel(player) >= 4) {
            player.getPersistentData().putBoolean(ACTIVE, false);
            player.displayClientMessage(net.minecraft.network.chat.Component.literal("§c¡Has alcanzado el límite máximo!"), true);
            return;
        }
        player.getPersistentData().putBoolean(ACTIVE, active);
        player.displayClientMessage(net.minecraft.network.chat.Component.literal(active ? "§bConcentrando Ki para romper tus límites..." : "§7Carga detenida."), true);
    }
    @SubscribeEvent
    public static void onPlayerTick(TickEvent.PlayerTickEvent event) {
        if (event.phase != TickEvent.Phase.END || !(event.player instanceof ServerPlayer player)) return;
        if (player.getPersistentData().getBoolean(ACTIVE)) {
            double charge = Math.min(MAX_CHARGE, getCharge(player) + 2.0D);
            player.getPersistentData().putDouble(ProgressionKeys.BREAK_CHARGE, charge);
            if (charge >= MAX_CHARGE) {
                player.getPersistentData().putDouble(ProgressionKeys.BREAK_CHARGE, 0.0D);
                int level = Math.min(4, getLevel(player) + 1);
                player.getPersistentData().putInt(ProgressionKeys.BREAK_LEVEL, level);
                player.getPersistentData().putBoolean(ACTIVE, false);
                player.getPersistentData().putInt(BURST_TICKS, 200);
                player.displayClientMessage(net.minecraft.network.chat.Component.literal("§6§l¡LÍMITE SUPERADO! §eNivel " + level + "/4"), true);
            }
        }
        int ticks = player.getPersistentData().getInt(BURST_TICKS);
        if (ticks > 0) {
            player.getPersistentData().putInt(BURST_TICKS, ticks - 1);
            int amp = Math.max(0, getLevel(player) - 1);
            player.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST, 25, amp, true, true, true));
            player.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 25, amp, true, true, true));
        }
    }
    public static boolean addCharge(ServerPlayer player, double amount) {
        if (!Double.isFinite(amount) || amount <= 0.0D) return false;
        double next = Math.min(MAX_CHARGE, getCharge(player) + amount);
        if (next >= MAX_CHARGE) {
            player.getPersistentData().putDouble(ProgressionKeys.BREAK_CHARGE, 0.0D);
            player.getPersistentData().putInt(ProgressionKeys.BREAK_LEVEL, Math.min(4, getLevel(player) + 1));
            return true;
        }
        player.getPersistentData().putDouble(ProgressionKeys.BREAK_CHARGE, next);
        return false;
    }
}
