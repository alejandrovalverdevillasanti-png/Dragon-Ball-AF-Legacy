package com.legacyofthesaiyans.progression;

import com.legacyofthesaiyans.LegacyOfTheSaiyans;
import com.legacyofthesaiyans.form.Form;
import com.legacyofthesaiyans.race.Race;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.UUID;

/** Race, form and attribute handling: the single place that recalculates all stat modifiers. */
@Mod.EventBusSubscriber(modid = LegacyOfTheSaiyans.MOD_ID, bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class StatsManager {
    private static final String ROOT = LegacyOfTheSaiyans.MOD_ID + ".";
    private static final String RACE_KEY = ROOT + "race";
    private static final String FORM_KEY = ROOT + "form";
    private static final String WISH_KI_KEY = ROOT + "wish_ki_bonus";

    private static final UUID ATTACK_UUID = UUID.fromString("5a2bcd71-6f44-4a42-9a41-4e7b9c8c1a10");
    private static final UUID HEALTH_UUID = UUID.fromString("5a2bcd71-6f44-4a42-9a41-4e7b9c8c1a11");
    private static final UUID SPEED_UUID = UUID.fromString("5a2bcd71-6f44-4a42-9a41-4e7b9c8c1a12");

    private StatsManager() {}

    public static Race getRace(Player player) {
        return Race.byId(player.getPersistentData().getString(RACE_KEY));
    }

    public static void setRace(ServerPlayer player, Race race) {
        CompoundTag data = player.getPersistentData();
        if (race == null) {
            data.remove(RACE_KEY);
        } else {
            data.putString(RACE_KEY, race.getId());
        }
        data.putString(FORM_KEY, Form.BASE.getId());
        recalc(player);
    }

    public static Form getForm(Player player) {
        return Form.byId(player.getPersistentData().getString(FORM_KEY));
    }

    public static void setForm(ServerPlayer player, Form form) {
        player.getPersistentData().putString(FORM_KEY, form.getId());
        recalc(player);
    }

    public static int getWishKiBonus(Player player) {
        return player.getPersistentData().getInt(WISH_KI_KEY);
    }

    public static void addWishKiBonus(ServerPlayer player, int amount) {
        CompoundTag data = player.getPersistentData();
        data.putInt(WISH_KI_KEY, data.getInt(WISH_KI_KEY) + amount);
    }

    public static void recalc(ServerPlayer player) {
        Race race = getRace(player);
        Form form = getForm(player);

        double attack = ZenkaiEvents.getAttackBonus(player) + form.getAttack() + (race != null ? race.getAttack() : 0.0D);
        double health = form.getHealth() + (race != null ? race.getHealth() : 0.0D);
        double speed = form.getSpeed() + (race != null ? race.getSpeed() : 0.0D);

        apply(player, Attributes.ATTACK_DAMAGE, ATTACK_UUID, "Legacy attack", attack, AttributeModifier.Operation.ADDITION);
        apply(player, Attributes.MAX_HEALTH, HEALTH_UUID, "Legacy health", health, AttributeModifier.Operation.ADDITION);
        apply(player, Attributes.MOVEMENT_SPEED, SPEED_UUID, "Legacy speed", speed, AttributeModifier.Operation.MULTIPLY_BASE);

        if (player.getHealth() > player.getMaxHealth()) {
            player.setHealth(player.getMaxHealth());
        }
    }

    private static void apply(ServerPlayer player, Attribute attribute, UUID id, String name,
                              double value, AttributeModifier.Operation operation) {
        AttributeInstance instance = player.getAttribute(attribute);
        if (instance == null) {
            return;
        }
        instance.removeModifier(id);
        if (value != 0.0D) {
            instance.addTransientModifier(new AttributeModifier(id, name, value, operation));
        }
    }

    @SubscribeEvent
    public static void onClone(PlayerEvent.Clone event) {
        CompoundTag oldData = event.getOriginal().getPersistentData();
        CompoundTag newData = event.getEntity().getPersistentData();
        if (oldData.contains(RACE_KEY)) {
            newData.putString(RACE_KEY, oldData.getString(RACE_KEY));
        }
        if (oldData.contains(WISH_KI_KEY)) {
            newData.putInt(WISH_KI_KEY, oldData.getInt(WISH_KI_KEY));
        }
    }
}
