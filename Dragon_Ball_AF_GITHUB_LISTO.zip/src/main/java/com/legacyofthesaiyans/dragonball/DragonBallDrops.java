package com.legacyofthesaiyans.dragonball;

import com.legacyofthesaiyans.LegacyOfTheSaiyans;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.boss.enderdragon.EnderDragon;
import net.minecraft.world.entity.boss.wither.WitherBoss;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Dragon Balls drop from hostile mobs killed by a player (rare) and always from bosses. */
@Mod.EventBusSubscriber(modid = LegacyOfTheSaiyans.MOD_ID, bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class DragonBallDrops {
    private static final float MOB_DROP_CHANCE = 0.02F;

    private DragonBallDrops() {}

    @SubscribeEvent
    public static void onDeath(LivingDeathEvent event) {
        LivingEntity victim = event.getEntity();
        if (victim.level().isClientSide() || !(event.getSource().getEntity() instanceof ServerPlayer)) {
            return;
        }
        boolean boss = victim instanceof EnderDragon || victim instanceof WitherBoss;
        if (!boss && !(victim instanceof Enemy)) {
            return;
        }
        if (boss || victim.getRandom().nextFloat() < MOB_DROP_CHANCE) {
            int index = victim.getRandom().nextInt(ModItems.DRAGON_BALLS.size());
            victim.spawnAtLocation(new ItemStack(ModItems.DRAGON_BALLS.get(index).get()));
        }
    }
}
