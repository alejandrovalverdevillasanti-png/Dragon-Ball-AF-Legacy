package com.legacyofthesaiyans.dragonball;

import com.legacyofthesaiyans.form.Form;
import com.legacyofthesaiyans.progression.StatsManager;
import com.legacyofthesaiyans.progression.ZenkaiEvents;
import com.legacyofthesaiyans.util.ChatUtil;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/** Summoning Shenron with the 7 Dragon Balls and granting one wish. */
public final class ShenronManager {
    private static final long WISH_WINDOW_TICKS = 1200L;
    private static final Map<UUID, Long> PENDING = new ConcurrentHashMap<>();

    private ShenronManager() {}

    public static void trySummon(ServerPlayer player) {
        boolean[] has = new boolean[7];
        int found = 0;
        for (ItemStack stack : player.getInventory().items) {
            if (stack.getItem() instanceof DragonBallItem ball) {
                int index = ball.getStars() - 1;
                if (index >= 0 && index < 7 && !has[index]) {
                    has[index] = true;
                    found++;
                }
            }
        }
        if (found < 7) {
            player.displayClientMessage(Component.literal("\u00A7eEsferas del Dragon distintas: " + found + " / 7"), true);
            return;
        }

        boolean[] used = new boolean[7];
        for (ItemStack stack : player.getInventory().items) {
            if (stack.getItem() instanceof DragonBallItem ball) {
                int index = ball.getStars() - 1;
                if (index >= 0 && index < 7 && !used[index]) {
                    used[index] = true;
                    stack.shrink(1);
                }
            }
        }

        ServerLevel level = player.serverLevel();
        LightningBolt bolt = EntityType.LIGHTNING_BOLT.create(level);
        if (bolt != null) {
            bolt.setPos(player.getX(), player.getY(), player.getZ());
            bolt.setVisualOnly(true);
            level.addFreshEntity(bolt);
        }
        level.playSound(null, player.getX(), player.getY(), player.getZ(),
                SoundEvents.LIGHTNING_BOLT_THUNDER, SoundSource.WEATHER, 3.0F, 0.8F);

        PENDING.put(player.getUUID(), level.getGameTime() + WISH_WINDOW_TICKS);

        player.sendSystemMessage(Component.literal("\u00A76\u00A1SHENRON HA DESPERTADO! \u00A7eTienes 60 segundos para pedir UN deseo:"));
        player.sendSystemMessage(ChatUtil.clickable("[+5 Zenkai]", "/shenron zenkai")
                .append(Component.literal("  "))
                .append(ChatUtil.clickable("[+30 Ki maximo]", "/shenron ki")));
        player.sendSystemMessage(ChatUtil.clickable("[32 diamantes]", "/shenron diamantes")
                .append(Component.literal("  "))
                .append(ChatUtil.clickable("[Cambiar de raza]", "/shenron raza")));
    }

    public static int grantWish(ServerPlayer player, String wish) {
        Long expires = PENDING.get(player.getUUID());
        if (expires == null || player.serverLevel().getGameTime() > expires) {
            PENDING.remove(player.getUUID());
            player.sendSystemMessage(Component.literal("\u00A7cShenron no esta aqui. Reune las 7 Esferas del Dragon y usalas (clic derecho)."));
            return 0;
        }
        PENDING.remove(player.getUUID());

        switch (wish) {
            case "zenkai" -> {
                ZenkaiEvents.addZenkai(player, 5.0D);
                player.sendSystemMessage(Component.literal("\u00A7aShenron te concede +5 de Zenkai permanente."));
            }
            case "ki" -> {
                StatsManager.addWishKiBonus(player, 30);
                player.sendSystemMessage(Component.literal("\u00A7aShenron aumenta tu Ki maximo en 30 para siempre."));
            }
            case "diamantes" -> {
                ItemStack diamonds = new ItemStack(Items.DIAMOND, 32);
                if (!player.getInventory().add(diamonds)) {
                    player.drop(diamonds, false);
                }
                player.sendSystemMessage(Component.literal("\u00A7aShenron te entrega 32 diamantes."));
            }
            case "raza" -> {
                StatsManager.setRace(player, null);
                StatsManager.setForm(player, Form.BASE);
                player.sendSystemMessage(Component.literal("\u00A7aTu raza ha sido borrada. Elige una nueva con \u00A7b/raza\u00A7a."));
            }
            default -> {
                return 0;
            }
        }

        ServerLevel level = player.serverLevel();
        level.playSound(null, player.getX(), player.getY(), player.getZ(),
                SoundEvents.BEACON_POWER_SELECT, SoundSource.PLAYERS, 2.0F, 1.0F);
        player.sendSystemMessage(Component.literal("\u00A76Shenron: \u00A7eTu deseo ha sido concedido. Adios."));
        return 1;
    }
}
