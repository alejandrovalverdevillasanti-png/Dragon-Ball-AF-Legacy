package com.legacyofthesaiyans.dragonball;

import com.legacyofthesaiyans.LegacyOfTheSaiyans;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Rarity;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

import java.util.ArrayList;
import java.util.List;

public final class ModItems {
    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, LegacyOfTheSaiyans.MOD_ID);

    public static final List<RegistryObject<Item>> DRAGON_BALLS = new ArrayList<>();

    static {
        for (int i = 1; i <= 7; i++) {
            final int stars = i;
            DRAGON_BALLS.add(ITEMS.register("dragon_ball_" + i,
                    () -> new DragonBallItem(new Item.Properties().stacksTo(1).fireResistant().rarity(Rarity.EPIC), stars)));
        }
    }

    private ModItems() {}
}
