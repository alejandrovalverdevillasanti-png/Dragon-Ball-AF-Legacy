package com.legacyofthesaiyans.dragonball;

import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

public class DragonBallItem extends Item {
    private final int stars;

    public DragonBallItem(Item.Properties properties, int stars) {
        super(properties);
        this.stars = stars;
    }

    public int getStars() {
        return stars;
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack held = player.getItemInHand(hand);
        if (!level.isClientSide() && player instanceof ServerPlayer serverPlayer) {
            ShenronManager.trySummon(serverPlayer);
        }
        return InteractionResultHolder.sidedSuccess(held, level.isClientSide());
    }
}
