package com.legacyofthesaiyans.race;

public enum Race {
    SAIYAN("saiyan", "Saiyan", 0.0D, 2.0D, 0.00D, 0, 1.5D),
    HUMAN("human", "Humano", 2.0D, 0.5D, 0.00D, 40, 1.2D),
    NAMEKIAN("namekian", "Namekiano", 6.0D, 0.5D, 0.00D, 10, 1.0D),
    MAJIN("majin", "Majin", 8.0D, 1.0D, -0.03D, 10, 1.0D),
    FRIEZA_CLAN("frieza_clan", "Clan de Freezer", 2.0D, 1.5D, 0.05D, 30, 1.0D),
    ANDROID("android", "Androide", 4.0D, 1.0D, 0.03D, 60, 0.8D),
    BIO_ANDROID("bio_android", "Bioandroide", 6.0D, 1.0D, 0.00D, 20, 1.1D),
    TUFFLE("tuffle", "Tuffle", 0.0D, 1.0D, 0.05D, 30, 1.1D),
    KAIOSHIN("kaioshin", "Kaioshin", 0.0D, 0.5D, 0.00D, 80, 1.0D),
    ANGEL("angel", "Angel", 0.0D, 1.5D, 0.08D, 50, 0.9D),
    DEMON("demon", "Demonio", 2.0D, 2.0D, 0.03D, 10, 1.0D),
    DRAGON("dragon", "Dragon", 10.0D, 1.0D, -0.02D, 10, 1.0D);

    private final String id;
    private final String displayName;
    private final double health;
    private final double attack;
    private final double speed;
    private final int kiBonus;
    private final double zenkaiMultiplier;

    Race(String id, String displayName, double health, double attack, double speed, int kiBonus, double zenkaiMultiplier) {
        this.id = id;
        this.displayName = displayName;
        this.health = health;
        this.attack = attack;
        this.speed = speed;
        this.kiBonus = kiBonus;
        this.zenkaiMultiplier = zenkaiMultiplier;
    }

    public String getId() { return id; }
    public String getDisplayName() { return displayName; }
    public double getHealth() { return health; }
    public double getAttack() { return attack; }
    public double getSpeed() { return speed; }
    public int getKiBonus() { return kiBonus; }
    public double getZenkaiMultiplier() { return zenkaiMultiplier; }

    public static Race byId(String id) {
        for (Race race : values()) {
            if (race.id.equals(id)) {
                return race;
            }
        }
        return null;
    }
}
