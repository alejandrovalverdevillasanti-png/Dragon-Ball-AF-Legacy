package com.legacyofthesaiyans.command;

import com.legacyofthesaiyans.LegacyOfTheSaiyans;
import com.legacyofthesaiyans.dragonball.ShenronManager;
import com.legacyofthesaiyans.form.Form;
import com.legacyofthesaiyans.ki.KiManager;
import com.legacyofthesaiyans.progression.StatsManager;
import com.legacyofthesaiyans.progression.ZenkaiEvents;
import com.legacyofthesaiyans.race.Race;
import com.legacyofthesaiyans.util.ChatUtil;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.Locale;

@Mod.EventBusSubscriber(modid = LegacyOfTheSaiyans.MOD_ID, bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class ModCommands {
    private ModCommands() {}

    @SubscribeEvent
    public static void onRegisterCommands(RegisterCommandsEvent event) {
        CommandDispatcher<CommandSourceStack> dispatcher = event.getDispatcher();

        dispatcher.register(Commands.literal("zenkai").executes(context -> {
            showStatus(context.getSource().getPlayerOrException());
            return 1;
        }));

        LiteralArgumentBuilder<CommandSourceStack> raza = Commands.literal("raza")
                .executes(context -> {
                    showRaces(context.getSource().getPlayerOrException());
                    return 1;
                });
        for (Race race : Race.values()) {
            raza.then(Commands.literal(race.getId()).executes(context -> {
                chooseRace(context.getSource().getPlayerOrException(), race);
                return 1;
            }));
        }
        dispatcher.register(raza);

        LiteralArgumentBuilder<CommandSourceStack> shenron = Commands.literal("shenron");
        for (String wish : new String[]{"zenkai", "ki", "diamantes", "raza"}) {
            shenron.then(Commands.literal(wish).executes(context ->
                    ShenronManager.grantWish(context.getSource().getPlayerOrException(), wish)));
        }
        dispatcher.register(shenron);
    }

    private static void showStatus(ServerPlayer player) {
        Race race = StatsManager.getRace(player);
        Form form = StatsManager.getForm(player);
        String text = String.format(Locale.ROOT,
                "\u00A76=== Estado ===\u00A7r\n"
                        + "Raza: \u00A7e%s\u00A7r\n"
                        + "Forma: \u00A7e%s\u00A7r\n"
                        + "Zenkai total: \u00A7e%.2f\u00A7r (muertes: %d)\n"
                        + "Bonus de ataque por Zenkai: \u00A7a+%.2f\u00A7r\n"
                        + "Ki: \u00A7b%d / %d\u00A7r",
                race != null ? race.getDisplayName() : "(sin elegir, usa /raza)",
                form.getDisplayName(),
                ZenkaiEvents.getZenkaiTotal(player),
                ZenkaiEvents.getZenkaiCount(player),
                ZenkaiEvents.getAttackBonus(player),
                KiManager.getKi(player),
                KiManager.getMaxKi(player));
        player.sendSystemMessage(Component.literal(text));
    }

    private static void showRaces(ServerPlayer player) {
        Race current = StatsManager.getRace(player);
        if (current != null) {
            player.sendSystemMessage(Component.literal("\u00A7eTu raza es \u00A76" + current.getDisplayName()
                    + "\u00A7e. Para cambiarla necesitas el deseo \"raza\" de Shenron."));
            return;
        }
        player.sendSystemMessage(Component.literal("\u00A76Elige tu raza (toca una):"));
        MutableComponent line = Component.literal("");
        for (Race race : Race.values()) {
            line.append(ChatUtil.clickable("[" + race.getDisplayName() + "]", "/raza " + race.getId()));
            line.append(Component.literal(" "));
        }
        player.sendSystemMessage(line);
    }

    private static void chooseRace(ServerPlayer player, Race race) {
        if (StatsManager.getRace(player) != null) {
            player.sendSystemMessage(Component.literal(
                    "\u00A7cYa tienes raza. Usa el deseo \"raza\" de Shenron para cambiarla."));
            return;
        }
        StatsManager.setRace(player, race);
        player.sendSystemMessage(Component.literal("\u00A7aAhora eres \u00A76" + race.getDisplayName()
                + "\u00A7a. Usa \u00A7b/zenkai\u00A7a para ver tus estadisticas."));
    }
}
