package com.legacyofthesaiyans.network;

import com.legacyofthesaiyans.client.ClientKiData;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** Server -> client. Current/max Ki plus race and form names for the HUD. */
public class KiSyncPacket {
    private final int ki;
    private final int maxKi;
    private final String race;
    private final String form;

    public KiSyncPacket(int ki, int maxKi, String race, String form) {
        this.ki = ki;
        this.maxKi = maxKi;
        this.race = race;
        this.form = form;
    }

    public static void encode(KiSyncPacket packet, FriendlyByteBuf buf) {
        buf.writeVarInt(packet.ki);
        buf.writeVarInt(packet.maxKi);
        buf.writeUtf(packet.race);
        buf.writeUtf(packet.form);
    }

    public static KiSyncPacket decode(FriendlyByteBuf buf) {
        return new KiSyncPacket(buf.readVarInt(), buf.readVarInt(), buf.readUtf(), buf.readUtf());
    }

    public static void handle(KiSyncPacket packet, Supplier<NetworkEvent.Context> ctxSupplier) {
        NetworkEvent.Context ctx = ctxSupplier.get();
        ctx.enqueueWork(() -> {
            ClientKiData.ki = packet.ki;
            ClientKiData.maxKi = packet.maxKi;
            ClientKiData.race = packet.race;
            ClientKiData.form = packet.form;
        });
        ctx.setPacketHandled(true);
    }
}
