package com.legacyofthesaiyans.network;

import com.legacyofthesaiyans.LegacyOfTheSaiyans;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.simple.SimpleChannel;

public final class ModNetwork {
    private static final String PROTOCOL = "1";

    public static final SimpleChannel CHANNEL = NetworkRegistry.newSimpleChannel(
            new ResourceLocation(LegacyOfTheSaiyans.MOD_ID, "main"),
            () -> PROTOCOL,
            PROTOCOL::equals,
            PROTOCOL::equals
    );

    private ModNetwork() {}

    public static void register() {
        int id = 0;
        CHANNEL.registerMessage(id++, KiActionPacket.class,
                KiActionPacket::encode, KiActionPacket::decode, KiActionPacket::handle);
        CHANNEL.registerMessage(id++, KiSyncPacket.class,
                KiSyncPacket::encode, KiSyncPacket::decode, KiSyncPacket::handle);
    }
}
