package com.legacyofthesaiyans;

import com.legacyofthesaiyans.config.LegacyConfig;
import com.legacyofthesaiyans.dragonball.ModItems;
import com.legacyofthesaiyans.network.ModNetwork;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.config.ModConfig;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

@Mod(LegacyOfTheSaiyans.MOD_ID)
public class LegacyOfTheSaiyans {
    public static final String MOD_ID = "legacyofthesaiyans";

    public LegacyOfTheSaiyans() {
        ModLoadingContext.get().registerConfig(ModConfig.Type.COMMON, LegacyConfig.SPEC);
        IEventBus modBus = FMLJavaModLoadingContext.get().getModEventBus();
        ModItems.ITEMS.register(modBus);
        modBus.addListener(this::commonSetup);
    }

    private void commonSetup(FMLCommonSetupEvent event) {
        event.enqueueWork(ModNetwork::register);
    }
}
