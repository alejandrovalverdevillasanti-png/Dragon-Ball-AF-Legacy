package com.legacyofthesaiyans.ki;

import com.legacyofthesaiyans.LegacyOfTheSaiyans;
import com.legacyofthesaiyans.form.Form;
import com.legacyofthesaiyans.form.TransformationManager;
import com.legacyofthesaiyans.network.KiSyncPacket;
import com.legacyofthesaiyans.network.ModNetwork;
import com.legacyofthesaiyans.progression.StatsManager;
import com.legacyofthesaiyans.progression.ZenkaiEvents;
import com.legacyofthesaiyans.race.Race;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.projectile.ProjectileUtil;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.LogicalSide;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.network.PacketDistributor;
import org.joml.Vector3f;

import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/** Server-side Ki system: charging, regeneration, form drain, the Ki blast and client sync. */
@Mod.EventBusSubscriber(modid = LegacyOfTheSaiyans.MOD_ID, bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class KiManager {
    private static final String KI_KEY = LegacyOfTheSaiyans.MOD_ID + ".ki";

    public static final int BASE_MAX_KI = 100;
    public static final int BLAST_COST = 30;
    private static final int BLAST_COOLDOWN_TICKS = 10;
    private static final double BLAST_RANGE = 32.0D;

    private static final Set<UUID> CHARGING = ConcurrentHashMap.newKeySet();
    private static final Map<UUID, String> LAST_SYNC = new ConcurrentHashMap<>();
    private static final Map<UUID, Long> LAST_FIRE = new ConcurrentHashMap<>();

    private KiManager() {}

    public static int getMaxKi(ServerPlayer player) {
        double zenkai = ZenkaiEvents.getZenkaiTotal(player);
        Race race = StatsManager.getRace(player);
        int raceBonus = race != null ? race.getKiBonus() : 0;
        return BASE_MAX_KI + (int) (Math.log1p(zenkai) * 20.0D) + raceBonus + StatsManager.getWishKiBonus(player);
    }

    public static int getKi(ServerPlayer player) {
        CompoundTag data = player.getPersistentData();
        if (!data.contains(KI_KEY)) {
            return getMaxKi(player);
        }
        return data.getInt(KI_KEY);
    }

    public static void setKi(ServerPlayer player, int value) {
        player.getPersistentData().putInt(KI_KEY, Mth.clamp(value, 0, getMaxKi(player)));
    }

    public static void setCharging(ServerPlayer player, boolean charging) {
        if (charging) {
            CHARGING.add(player.getUUID());
        } else {
            CHARGING.remove(player.getUUID());
        }
    }

    public static void tryFire(ServerPlayer player) {
        long now = player.serverLevel().getGameTime();
        Long last = LAST_FIRE.get(player.getUUID());
        if (last != null && now - last < BLAST_COOLDOWN_TICKS) {
            return;
        }
        int ki = getKi(player);
        if (ki < BLAST_COST) {
            player.displayClientMessage(Component.literal("\u00A7cNo tienes suficiente Ki"), true);
            return;
        }
        LAST_FIRE.put(player.getUUID(), now);
        setKi(player, ki - BLAST_COST);
        fireBlast(player);
    }

    private static void fireBlast(ServerPlayer player) {
        ServerLevel level = player.serverLevel();
        Vec3 start = player.getEyePosition();
        Vec3 look = player.getLookAngle();
        Vec3 end = start.add(look.scale(BLAST_RANGE));

        BlockHitResult blockHit = level.clip(new ClipContext(
                start, end, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, player));
        if (blockHit.getType() != HitResult.Type.MISS) {
            end = blockHit.getLocation();
        }

        AABB searchBox = player.getBoundingBox().expandTowards(end.subtract(start)).inflate(1.0D);
        EntityHitResult entityHit = ProjectileUtil.getEntityHitResult(
                level, player, start, end, searchBox,
                e -> !e.isSpectator() && e.isPickable() && e != player);
        if (entityHit != null) {
            Entity target = entityHit.getEntity();
            end = entityHit.getLocation();
            double bonus = Math.log1p(ZenkaiEvents.getZenkaiTotal(player)) * 2.0D;
            double formBonus = StatsManager.getForm(player).getAttack() * 0.5D;
            target.hurt(player.damageSources().playerAttack(player), (float) (6.0D + bonus + formBonus));
        }

        Vec3 direction = end.subtract(start);
        double length = direction.length();
        if (length > 0.01D) {
            Vec3 step = direction.normalize().scale(0.6D);
            Vec3 pos = start.add(look.scale(0.8D));
            int steps = (int) (length / 0.6D);
            for (int i = 0; i < steps; i++) {
                level.sendParticles(ParticleTypes.END_ROD, pos.x, pos.y - 0.2D, pos.z, 1, 0.0D, 0.0D, 0.0D, 0.0D);
                pos = pos.add(step);
            }
        }
        level.sendParticles(ParticleTypes.EXPLOSION, end.x, end.y, end.z, 1, 0.0D, 0.0D, 0.0D, 0.0D);
        level.playSound(null, player.getX(), player.getY(), player.getZ(),
                SoundEvents.BLAZE_SHOOT, SoundSource.PLAYERS, 1.0F, 1.4F);
    }

    @SubscribeEvent
    public static void onPlayerTick(TickEvent.PlayerTickEvent event) {
        if (event.phase != TickEvent.Phase.END || event.side != LogicalSide.SERVER) {
            return;
        }
        if (!(event.player instanceof ServerPlayer player)) {
            return;
        }

        int max = getMaxKi(player);
        int ki = getKi(player);
        boolean charging = CHARGING.contains(player.getUUID());
        Form form = StatsManager.getForm(player);
        ServerLevel level = player.serverLevel();

        if (charging) {
            ki += 1;
            if (player.tickCount % 3 == 0) {
                level.sendParticles(ParticleTypes.ELECTRIC_SPARK,
                        player.getX(), player.getY() + 1.0D, player.getZ(), 3, 0.4D, 0.6D, 0.4D, 0.05D);
            }
        } else if (form == Form.BASE && player.tickCount % 20 == 0) {
            ki += 1;
        }

        if (form != Form.BASE) {
            if (player.tickCount % 20 == 0) {
                ki -= form.getKiDrainPerSecond();
            }
            if (player.tickCount % 4 == 0) {
                level.sendParticles(new DustParticleOptions(new Vector3f(form.getRed(), form.getGreen(), form.getBlue()), 1.0F),
                        player.getX(), player.getY() + 1.0D, player.getZ(), 4, 0.35D, 0.7D, 0.35D, 0.0D);
            }
        }

        ki = Mth.clamp(ki, 0, max);
        player.getPersistentData().putInt(KI_KEY, ki);

        if (form != Form.BASE && ki <= 0) {
            TransformationManager.revert(player, "Te quedaste sin Ki");
            form = StatsManager.getForm(player);
        }

        Race race = StatsManager.getRace(player);
        String raceName = race != null ? race.getDisplayName() : "";
        String formName = form.getDisplayName();
        String key = ki + "|" + max + "|" + raceName + "|" + formName;
        if (!key.equals(LAST_SYNC.get(player.getUUID()))) {
            LAST_SYNC.put(player.getUUID(), key);
            ModNetwork.CHANNEL.send(PacketDistributor.PLAYER.with(() -> player),
                    new KiSyncPacket(ki, max, raceName, formName));
        }
    }

    @SubscribeEvent
    public static void onClone(PlayerEvent.Clone event) {
        CompoundTag oldData = event.getOriginal().getPersistentData();
        if (oldData.contains(KI_KEY)) {
            event.getEntity().getPersistentData().putInt(KI_KEY, oldData.getInt(KI_KEY));
        }
    }

    @SubscribeEvent
    public static void onLogin(PlayerEvent.PlayerLoggedInEvent event) {
        LAST_SYNC.remove(event.getEntity().getUUID());
    }

    @SubscribeEvent
    public static void onRespawn(PlayerEvent.PlayerRespawnEvent event) {
        LAST_SYNC.remove(event.getEntity().getUUID());
    }

    @SubscribeEvent
    public static void onLogout(PlayerEvent.PlayerLoggedOutEvent event) {
        UUID id = event.getEntity().getUUID();
        CHARGING.remove(id);
        LAST_SYNC.remove(id);
        LAST_FIRE.remove(id);
    }
}
