package com.legacyofthesaiyans.config;

import net.minecraftforge.common.ForgeConfigSpec;

public final class LegacyConfig {
    public static final ForgeConfigSpec SPEC;
    public static final ForgeConfigSpec.BooleanValue ENABLE_BREAK_LIMIT;
    public static final ForgeConfigSpec.BooleanValue ENABLE_PERMANENT_ZENKAI;
    public static final ForgeConfigSpec.BooleanValue ENABLE_LEGENDARY_POTENTIAL;
    public static final ForgeConfigSpec.DoubleValue ZENKAI_BASE_MULTIPLIER;

    static {
        ForgeConfigSpec.Builder builder = new ForgeConfigSpec.Builder();

        builder.push("progression");
        ENABLE_BREAK_LIMIT = builder
                .comment("Enable the rapid-key-press Break Limit mechanic.")
                .define("enableBreakLimit", true);
        ENABLE_PERMANENT_ZENKAI = builder
                .comment("Keep earned Zenkai progression permanently, including after death.")
                .define("enablePermanentZenkai", true);
        ENABLE_LEGENDARY_POTENTIAL = builder
                .comment("Enable the rare Legendary Saiyan potential trait.")
                .define("enableLegendaryPotential", true);
        ZENKAI_BASE_MULTIPLIER = builder
                .comment("Base scaling factor for Zenkai rewards. Final balancing will be tested in-game.")
                .defineInRange("zenkaiBaseMultiplier", 1.0D, 0.1D, 10.0D);
        builder.pop();

        SPEC = builder.build();
    }

    private LegacyConfig() {}
}
