package com.legacyofthesaiyans.client;

import com.legacyofthesaiyans.LegacyOfTheSaiyans;
import com.legacyofthesaiyans.network.KiActionPacket;
import com.legacyofthesaiyans.network.ModNetwork;
import net.minecraft.client.Minecraft;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = LegacyOfTheSaiyans.MOD_ID, bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
public final class ClientForgeEvents {
    private static boolean charging = false;
    private static boolean breakingLimit = false;

    private ClientForgeEvents() {}

    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) {
            return;
        }
        Minecraft mc = Minecraft.getInstance();
        boolean down = mc.player != null && mc.screen == null && KeyBindings.CHARGE_KI.isDown();
        if (down != charging) {
            charging = down;
            ModNetwork.CHANNEL.sendToServer(new KiActionPacket(down ? 1 : 0));
        }
        boolean breakDown = mc.player != null && mc.screen == null && KeyBindings.BREAK_LIMIT.isDown();
        if (breakDown != breakingLimit) {
            breakingLimit = breakDown;
            ModNetwork.CHANNEL.sendToServer(new KiActionPacket(breakDown ? 5 : 6));
        }
        while (KeyBindings.FIRE_KI.consumeClick()) {
            if (mc.player != null && mc.screen == null) {
                ModNetwork.CHANNEL.sendToServer(new KiActionPacket(2));
            }
        }
        while (KeyBindings.TRANSFORM.consumeClick()) {
            if (mc.player != null && mc.screen == null) {
                ModNetwork.CHANNEL.sendToServer(new KiActionPacket(3));
            }
        }
        while (KeyBindings.REVERT.consumeClick()) {
            if (mc.player != null && mc.screen == null) {
                ModNetwork.CHANNEL.sendToServer(new KiActionPacket(4));
            }
        }
    }
}
