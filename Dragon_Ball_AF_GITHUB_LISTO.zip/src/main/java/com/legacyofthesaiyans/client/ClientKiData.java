package com.legacyofthesaiyans.client;

/** Plain holder for the values received from the server (safe to load on any side). */
public final class ClientKiData {
    public static volatile int ki = 0;
    public static volatile int maxKi = 0;
    public static volatile String race = "";
    public static volatile String form = "";

    private ClientKiData() {}
}
