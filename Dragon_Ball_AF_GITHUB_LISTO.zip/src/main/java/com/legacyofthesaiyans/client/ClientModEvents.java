package com.legacyofthesaiyans.client;

import com.legacyofthesaiyans.LegacyOfTheSaiyans;
import net.minecraft.client.Minecraft;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RegisterGuiOverlaysEvent;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = LegacyOfTheSaiyans.MOD_ID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public final class ClientModEvents {
    private ClientModEvents() {}

    @SubscribeEvent
    public static void onRegisterKeys(RegisterKeyMappingsEvent event) {
        event.register(KeyBindings.CHARGE_KI);
        event.register(KeyBindings.FIRE_KI);
        event.register(KeyBindings.TRANSFORM);
        event.register(KeyBindings.REVERT);
        event.register(KeyBindings.BREAK_LIMIT);
    }

    @SubscribeEvent
    public static void onRegisterOverlays(RegisterGuiOverlaysEvent event) {
        event.registerAboveAll("ki_bar", (gui, graphics, partialTick, width, height) -> {
            int max = ClientKiData.maxKi;
            if (max <= 0) {
                return;
            }
            Minecraft mc = Minecraft.getInstance();
            if (mc.player == null || mc.options.hideGui) {
                return;
            }
            int ki = Math.max(0, Math.min(ClientKiData.ki, max));
            int barWidth = 100;
            int barHeight = 8;
            int x = 10;
            int y = 10;
            int filled = barWidth * ki / max;

            graphics.fill(x - 1, y - 1, x + barWidth + 1, y + barHeight + 1, 0xAA000000);
            graphics.fill(x, y, x + filled, y + barHeight, 0xFF33CCFF);
            graphics.drawString(mc.font, "Ki " + ki + " / " + max, x, y + barHeight + 3, 0xFFFFFF);
            String race = ClientKiData.race;
            String form = ClientKiData.form;
            if (!race.isEmpty()) {
                graphics.drawString(mc.font, race + " - " + form, x, y + barHeight + 15, 0xFFD966);
            }
        });
    }
}
