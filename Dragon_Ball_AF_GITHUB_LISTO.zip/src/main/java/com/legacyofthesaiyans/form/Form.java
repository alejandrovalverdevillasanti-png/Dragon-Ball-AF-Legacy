package com.legacyofthesaiyans.form;

import com.legacyofthesaiyans.race.Race;

public enum Form {
    BASE("base", "Base", false, false, 0.0D, 0.0D, 0.0D, 0.00D, 0, 1.0F, 1.0F, 1.0F),
    KAIOKEN("kaioken", "Kaioken", false, false, 1.0D, 3.0D, 0.0D, 0.10D, 3, 1.0F, 0.1F, 0.1F),
    SUPER_SAIYAN("super_saiyan", "Super Saiyan", true, false, 2.0D, 4.0D, 4.0D, 0.15D, 2, 1.0F, 0.85F, 0.1F),
    SUPER_SAIYAN_2("super_saiyan_2", "Super Saiyan 2", true, false, 5.0D, 7.0D, 6.0D, 0.20D, 3, 1.0F, 0.9F, 0.3F),
    SUPER_SAIYAN_3("super_saiyan_3", "Super Saiyan 3", true, false, 10.0D, 11.0D, 8.0D, 0.25D, 5, 1.0F, 0.8F, 0.0F),
    SUPER_SAIYAN_4("super_saiyan_4", "Super Saiyan 4", true, false, 18.0D, 15.0D, 10.0D, 0.30D, 4, 0.8F, 0.1F, 0.1F),
    SUPER_SAIYAN_GOD("super_saiyan_god", "Super Saiyan God", true, false, 28.0D, 18.0D, 12.0D, 0.35D, 5, 1.0F, 0.2F, 0.3F),
    SUPER_SAIYAN_BLUE("super_saiyan_blue", "Super Saiyan Blue", true, false, 40.0D, 24.0D, 14.0D, 0.40D, 6, 0.2F, 0.6F, 1.0F),
    ULTRA_INSTINCT("ultra_instinct", "Ultra Instinto", true, false, 60.0D, 32.0D, 16.0D, 0.50D, 8, 0.9F, 0.9F, 1.0F),
    POTENTIAL_UNLEASHED("potential_unleashed", "Potencial Desatado", false, true, 2.0D, 4.0D, 4.0D, 0.15D, 2, 0.9F, 0.9F, 0.6F),
    ULTIMATE("ultimate", "Forma Definitiva", false, true, 10.0D, 12.0D, 8.0D, 0.30D, 4, 0.7F, 0.3F, 1.0F);

    private final String id;
    private final String displayName;
    private final boolean saiyanOnly;
    private final boolean nonSaiyanOnly;
    private final double minZenkai;
    private final double attack;
    private final double health;
    private final double speed;
    private final int kiDrainPerSecond;
    private final float red;
    private final float green;
    private final float blue;

    Form(String id, String displayName, boolean saiyanOnly, boolean nonSaiyanOnly, double minZenkai,
         double attack, double health, double speed, int kiDrainPerSecond,
         float red, float green, float blue) {
        this.id = id;
        this.displayName = displayName;
        this.saiyanOnly = saiyanOnly;
        this.nonSaiyanOnly = nonSaiyanOnly;
        this.minZenkai = minZenkai;
        this.attack = attack;
        this.health = health;
        this.speed = speed;
        this.kiDrainPerSecond = kiDrainPerSecond;
        this.red = red;
        this.green = green;
        this.blue = blue;
    }

    public String getId() { return id; }
    public String getDisplayName() { return displayName; }
    public double getMinZenkai() { return minZenkai; }
    public double getAttack() { return attack; }
    public double getHealth() { return health; }
    public double getSpeed() { return speed; }
    public int getKiDrainPerSecond() { return kiDrainPerSecond; }
    public float getRed() { return red; }
    public float getGreen() { return green; }
    public float getBlue() { return blue; }

    public boolean isAvailable(Race race, double zenkai) {
        if (this == BASE || race == null) {
            return false;
        }
        if (saiyanOnly && race != Race.SAIYAN) {
            return false;
        }
        if (nonSaiyanOnly && race == Race.SAIYAN) {
            return false;
        }
        return zenkai >= minZenkai;
    }

    public static Form byId(String id) {
        for (Form form : values()) {
            if (form.id.equals(id)) {
                return form;
            }
        }
        return BASE;
    }
}
