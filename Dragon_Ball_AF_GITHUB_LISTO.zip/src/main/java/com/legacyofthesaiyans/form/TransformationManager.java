package com.legacyofthesaiyans.form;

import com.legacyofthesaiyans.ki.KiManager;
import com.legacyofthesaiyans.progression.StatsManager;
import com.legacyofthesaiyans.progression.ZenkaiEvents;
import com.legacyofthesaiyans.race.Race;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;

public final class TransformationManager {
    public static final int TRANSFORM_COST = 10;

    private TransformationManager() {}

    public static void transformUp(ServerPlayer player) {
        Race race = StatsManager.getRace(player);
        if (race == null) {
            player.displayClientMessage(Component.literal("\u00A7cPrimero elige tu raza con /raza"), true);
            return;
        }
        double zenkai = ZenkaiEvents.getZenkaiTotal(player);
        Form current = StatsManager.getForm(player);

        Form next = null;
        for (Form form : Form.values()) {
            if (form.ordinal() > current.ordinal() && form.isAvailable(race, zenkai)) {
                next = form;
                break;
            }
        }
        if (next == null) {
            player.displayClientMessage(Component.literal("\u00A7eNo hay una forma superior disponible. Consigue mas Zenkai."), true);
            return;
        }

        int ki = KiManager.getKi(player);
        if (ki < TRANSFORM_COST) {
            player.displayClientMessage(Component.literal("\u00A7cNo tienes suficiente Ki para transformarte"), true);
            return;
        }
        KiManager.setKi(player, ki - TRANSFORM_COST);
        StatsManager.setForm(player, next);

        player.serverLevel().playSound(null, player.getX(), player.getY(), player.getZ(),
                SoundEvents.BEACON_ACTIVATE, SoundSource.PLAYERS, 1.5F, 1.2F);
        player.displayClientMessage(Component.literal("\u00A76\u00A1" + next.getDisplayName() + "!"), true);
    }

    public static void revert(ServerPlayer player, String reason) {
        if (StatsManager.getForm(player) == Form.BASE) {
            return;
        }
        StatsManager.setForm(player, Form.BASE);
        if (reason != null) {
            player.displayClientMessage(Component.literal("\u00A7e" + reason), true);
        }
    }
}
